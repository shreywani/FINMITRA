function calculateEMI() {
    const loanAmount = parseFloat(document.getElementById("loan-amount").value);
    const interestRate = parseFloat(document.getElementById("interest-rate").value);
    const loanTerm = parseInt(document.getElementById("loan-term").value);
    
    const monthlyInterestRate = interestRate / (12 * 100);
    const denominator = Math.pow(1 + monthlyInterestRate, loanTerm) - 1;
    const emi = (loanAmount * monthlyInterestRate) / denominator * (1 + monthlyInterestRate);
    
    document.getElementById("result").innerText = `Your monthly EMI is Rs. ${emi.toFixed(2)}`;
  }
  